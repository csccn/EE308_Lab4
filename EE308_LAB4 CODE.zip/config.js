const config = {
  baseUrl: 'https://bobing.quanqiuqipai.com'
  //baseUrl : 'https://bobing.55085.cn'
  //baseUrl: 'http://192.168.1.100'
}

export default config;